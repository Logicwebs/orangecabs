<?php $p = 'home'; include('header.php')?>
<header class="header">

<div class="header__text-box">
    <div class="row">
        <div class="col-1-of-2">
            <div class="margin-right-medium margin-bottom-medium">
                <img src="src/images/mobile.png" alt="mobile">
                <p><a href="#profileusers">APP <br> BOOKINGS</a></p>
            </div>
        </div>
        <div class="col-1-of-2">
            <div class="margin-left-medium header__title">
                <img src="src/images/screen.png" width="150" alt="screen" class="screen">
                <p><a href="?p=onlinebookings">ONLINE <br> BOOKINGS</a></p>
            </div>
        </div>
    </div>

</div>
</header>

<?php include('footer.php');?>