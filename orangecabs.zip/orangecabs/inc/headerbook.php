<?php 
// session_start();
// include('../func/connection.php');

// $user_id = $_SESSION['user_id'];

//     //get username and email
// $sql = "SELECT * FROM users WHERE user_id='$user_id'";

// $result = mysqli_query($link, $sql);

// $count = mysqli_num_rows($result);

// if ($count == 1) {

//     $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

//     $username = $row['username'];
//     $mobile = $row['mobile'];
//     $email = $row['email'];

// } else {

//     echo "There was an error retrieving the username and email from the database!";

// }
?>
   
  