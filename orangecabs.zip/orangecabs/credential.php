<?php 
define('EMAIL','mwalilanyira@gmail.com');
define('PASS', 'demwantambo89');

?>